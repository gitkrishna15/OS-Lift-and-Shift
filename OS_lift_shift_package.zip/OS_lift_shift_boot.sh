# Script to prepare source server for image
# Execute without parameter for it to execute steps for boot prepare execution
usage(){
        echo "Usage: $0 <keyword>
        rollback : performs rollback of steps in prepare stage to revert to previous state"
        DEFAULT option will prepare the system for changes
exit 1
}
main(){
case $1 in
"rollback")
 uname -r > version.txt
 V=$(cat version.txt | cut -d'.' -f 6 | cut -c3)

 if [[ "$V" -eq 7 ]] ; then
        for f in `ls /boot/*img*` ; do mv $f $BACKUP_DIR/$(basename $f)_edited_$CURRDATE; done;
        for f in `ls $BACKUP_DIR/*img*|grep -v *img*_edited*` ; do cp -p $f /boot/`echo $(basename $f)`; done;
        for f in `ls /boot/*img*` ; do N=`ls $f | awk -F '.img' '{print $1}'`;
        mv $f `echo $N`.img; done;
		if [ -f /usr/lib/systemd/system/OS_lift_shift.service ]; then
			mv /usr/lib/systemd/system/OS_lift_shift.service $BACKUP_DIR/
		fi
 elif [[ "$V" -eq 6 ]] ; then
		chkconfig --del /etc/init.d/OS_lift_shift_prep
		mv /etc/init.d/OS_lift_shift_prep $BACKUP_DIR/
 fi
;;
*)
echo "Place the zip file in stage directory."
echo
echo "Enter the path where to stage the scripts and backup files:  "
read STAGING_PATH
BACKUP_DIR=`echo $STAGING_PATH`/OSLS/backup_dir_cloud
CURRDATE=`date +"%Y%m%d_%H%M"`
unzip -d $STAGING_PATH/ $STAGING_PATH/OS_lift_shift_all.zip
mkdir -p $BACKUP_DIR
sed -i -e "s|prepared|${STAGING_PATH}\/OSLS\/prepared|g" $STAGING_PATH/OSLS/OS_lift_shift_prep.sh
sed -i -e "s|OS_lift_shift_setenv.env|${STAGING_PATH}\/OSLS\/OS_lift_shift_setenv.env|g" $STAGING_PATH/OSLS/OS_lift_shift_prep.sh
sed -i -e "s|backup_dir_cloud|${STAGING_PATH}\/OSLS\/backup_dir_cloud|g" $STAGING_PATH/OSLS/OS_lift_shift_prep.sh
uname -r > version.txt
V=$(cat version.txt | cut -d'.' -f 6 | cut -c3)
if [[ "$V" -eq 7 ]] ; then
	touch /usr/lib/systemd/system/OS_lift_shift.service
	echo "
[Unit]
#Description= onBoot server daemon
After=network.target
#Wants=sshd-keygen.service

[Service]
#EnvironmentFile=/etc/sysconfig/sshd
ExecStart=$STAGING_PATH/OSLS/OS_lift_shift_prep.sh
ExecReload=/bin/kill -HUP $MAINPID
KillMode=process
Restart=on-failure
RestartSec=42s

[Install]
WantedBy=multi-user.target

" >>/usr/lib/systemd/system/OS_lift_shift.service
	systemctl enable OS_lift_shift
	for f in `ls /boot/*img*`; do mv $f $BACKUP_DIR/$(basename $f)_backup_$CURRDATE;
		dracut --add-drivers "xen-blkfront xen-netfront" $f; done;
elif [[ "$V" -eq 6 ]] ; then
	cp -p $STAGING_PATH/OSLS/OS_lift_shift_prep.sh /etc/init.d/OS_lift_shift_prep
	chmod 750 /etc/init.d/OS_lift_shift_prep
	sed -i "2i #chkconfig: 345 90 01" /etc/init.d/OS_lift_shift_prep
	chkconfig --add /etc/init.d/OS_lift_shift_prep
fi
chmod +x $STAGING_PATH/OSLS/*.sh
;;
esac
}
if [ $# -gt 1 ] ; then
usage
fi
main $*